# Lake Peigneur — Animated Short Source

A 64-second, 9:16 animated short about the November 20, 1980 Lake Peigneur disaster. Built with **Remotion + Three.js + React Three Fiber**, using the uploaded `claude-animated-shorts` skill as the technical/visual reference. The story, characters, scene composition and assets in this project are original.

## What is included

- `src/videos/lakePeigneur/` — complete scene source: timeline, procedural world, rig, lake, underground salt mine cutaway, canal, whirlpool, character cards, lighting and post-processing.
- `src/Root.tsx`, `src/index.ts` — Remotion composition registration.
- `SCRIPT.md` — fact sheet, clean narration, timed story beats and sound direction.
- `public/audio/lake-peigneur-score.wav` — original 64-second atmospheric score.
- `public/audio/lake-peigneur-sfx.wav` — original synchronized ambience/action sound bed.
- `scripts/make_audio.py` and `scripts/make_sfx.py` — reproducible audio generators; standard Python only.
- `.github/workflows/render-lake-peigneur.yml` — manual GitHub Actions render workflow. It is not run automatically by this project.

## Technical target

- 1080 × 1920, vertical 9:16
- 30 fps, 1,920 frames / 64 seconds
- Three.js 0.175.0, React Three Fiber 9.1.2
- Remotion 4.0.290, `@remotion/three` 4.0.290
- `@react-three/postprocessing` 3.0.4, `postprocessing` 6.37.2
- Final quality scale in the workflow: 1.3333 (1440 × 2560)

## Setup

1. Put this project folder in a GitHub repository, or merge `src/`, `public/`, `scripts/`, `package.json`, `tsconfig.json`, and `remotion.config.ts` into your existing Remotion project.
2. Install dependencies with `npm install`.
3. Regenerate the score if needed: `python scripts/make_audio.py`.
4. Add your generated narration as `public/audio/voice.wav` (48 kHz WAV recommended). The score and designed SFX bed are already included.
5. In the GitHub Actions workflow, the render command passes `voiceFile: audio/voice.wav`. If you do not add voice audio, remove that props argument; the animation and score still work.
6. Run `npm run typecheck` in your own environment before rendering.

## Local commands

- `npm run start` — open Remotion Studio.
- `npm run typecheck` — TypeScript check.
- `npm run render` — high-quality local render (not executed during this delivery).

## GitHub Actions

Open **Actions → Render Lake Peigneur Short → Run workflow**. Choose the scale. `1` means 1080 × 1920; `1.3333` means 1440 × 2560. This workflow uses manual dispatch only, uploads the rendered MP4 as an artifact, and does not run on every push.

## Voiceover integration

The composition accepts a Remotion input prop named `voiceFile`. Example props JSON:

```json
{"voiceFile":"audio/voice.wav"}
```

The clean voiceover is in `SCRIPT.md`. The score is already included and mixed quietly under the narration. Record or generate the voice track separately; no synthetic voice is fabricated or silently substituted.

## Creative / factual notes

The underground mine is a simplified explanatory cutaway, not a precise engineering reconstruction. The exact initial breach geometry is not depicted as a known fact. The narration uses “within hours” rather than choosing between conflicting secondary estimates of the draining time. Sources are listed in `SCRIPT.md`.

## Important

This delivery contains source code and a score asset only. **No video render, preview render, or export was run.**
