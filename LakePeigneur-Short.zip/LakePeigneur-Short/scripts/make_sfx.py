"""Create deterministic, original environmental/action SFX bed for the 64-second short.
Uses only Python's standard library; output is 48 kHz stereo WAV.
"""
import math, random, struct, wave
from pathlib import Path
SR=48000; DUR=64
OUT=Path(__file__).resolve().parents[1]/'public'/'audio'/'lake-peigneur-sfx.wav'
random.seed(19801120)
def env(t,start,end,attack=.4,release=.8):
    if t<start or t>end:return 0.0
    return min(1,(t-start)/max(attack,.001),(end-t)/max(release,.001))
def noise(): return random.uniform(-1,1)
with wave.open(str(OUT),'wb') as w:
    w.setnchannels(2);w.setsampwidth(2);w.setframerate(SR)
    block=bytearray()
    for i in range(SR*DUR):
        t=i/SR
        # Soft lake/wind ambience throughout.
        amb=.025*noise()
        # Low diesel drilling motor, then a stressed mechanical groan.
        motor=env(t,5,25,2,2)*(.035*math.sin(2*math.pi*48*t)+.018*math.sin(2*math.pi*96*t))
        creak=env(t,17,24,1.5,1.0)*(.045*math.sin(2*math.pi*(110+18*math.sin(t*2))*t))
        # Underground rumble rises as the breach develops.
        rumble=env(t,21,43,3,3)*(.065*math.sin(2*math.pi*31*t)+.025*math.sin(2*math.pi*43*t))
        # Broadband water rush and vortex texture.
        rush=env(t,25,48,3,2)*(.07*noise())
        swirl=env(t,31,46,2,2)*(.035*math.sin(2*math.pi*(65+10*math.sin(t*1.7))*t))
        # Short low impacts at the rig tilt and equipment being pulled in.
        hit=0.0
        for when,amp in [(29.0,.12),(34.5,.16),(39.2,.19),(42.0,.11)]:
            dt=t-when
            if 0<=dt<.8: hit+=amp*math.exp(-dt*9)*math.sin(2*math.pi*(70-45*dt)*dt)
        # Reversing canal waterfall, then calm wind in the ending.
        fall=env(t,43,55,2,3)*(.055*noise()+.018*math.sin(2*math.pi*82*t))
        calm=env(t,53,64,2,2)*(.018*noise())
        x=amb+motor+creak+rumble+rush+swirl+hit+fall+calm
        # Soft saturation and a tiny stereo spread.
        l=math.tanh(x*2.0)*.65
        r=math.tanh((x*.96+.006*math.sin(2*math.pi*.21*t))*2.0)*.65
        block.extend(struct.pack('<hh',int(l*32767),int(r*32767)))
        if len(block)>=65536:w.writeframesraw(block);block.clear()
    if block:w.writeframesraw(block)
print(OUT)
