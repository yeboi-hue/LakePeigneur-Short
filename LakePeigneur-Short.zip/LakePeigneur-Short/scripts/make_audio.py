"""Generate an original 64-second atmospheric score bed (48 kHz stereo WAV).
No voice is synthesized here; record/generate the narration from SCRIPT.md separately.
"""
import math, wave, struct
from pathlib import Path

SR=48000
DURATION=64
OUT=Path(__file__).resolve().parents[1]/'public'/'audio'/'lake-peigneur-score.wav'
OUT.parent.mkdir(parents=True,exist_ok=True)
# A restrained original ambient score: low pulses, distant metallic tones and a warm resolution.
chords=[(0,16,(55.0,82.41,110.0)),(16,30,(49.0,73.42,98.0)),(30,44,(41.2,61.74,82.41)),(44,55,(46.25,69.3,92.5)),(55,64,(55.0,82.41,110.0))]
with wave.open(str(OUT),'wb') as w:
    w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR)
    block=bytearray()
    for i in range(SR*DURATION):
        t=i/SR
        chord=next(c for a,b,c in chords if a<=t<b)
        # Slow fade-in/out, plus a restrained swell around the breach.
        fade=min(1.0,t/2.5,(DURATION-t)/3.0)
        swell=0.58+0.30*math.exp(-((t-35)/8.0)**2)
        sample=0.0
        for j,f in enumerate(chord):
            phase=2*math.pi*f*t
            sample+=(0.42/(j+1))*math.sin(phase+0.12*math.sin(2*math.pi*.08*t))
            sample+=0.10/(j+1)*math.sin(phase*2.003)
        # Gentle rhythmic low pulse; no sharp transients.
        pulse=(0.5+0.5*math.sin(2*math.pi*.72*t))**5
        sample+=0.10*pulse*math.sin(2*math.pi*41.2*t)
        # Airy upper harmonic, very quiet.
        sample+=0.025*math.sin(2*math.pi*329.63*t+0.3*math.sin(2*math.pi*.11*t))
        sample*=0.105*fade*swell
        # Stereo width from a slow, subtle phase offset.
        left=max(-1,min(1,sample))
        right=max(-1,min(1,sample*0.96+0.012*math.sin(2*math.pi*.17*t)))
        block.extend(struct.pack('<hh',int(left*32767),int(right*32767)))
        if len(block)>=65536:
            w.writeframesraw(block);block.clear()
    if block:w.writeframesraw(block)
print(OUT)
