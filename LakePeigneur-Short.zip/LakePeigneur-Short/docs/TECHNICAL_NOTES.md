# Technical implementation notes

## Reference architecture carried forward

The source follows the supplied skill's Remotion + Three.js composition structure and reuses its post-processing implementations for screen-space world ink, thin-lens depth of field and display-referred grading. The Lake Peigneur-specific story, world geometry, camera path, character art and scene construction are new.

## Module ownership

- `story.ts`: 30 fps frame count, 13 shot blocks, camera targets, focus distances and deterministic event curves.
- `lights.ts`: day / storm / golden presets and the visual palette.
- `build.ts`: procedural geometry and deterministic painted water texture.
- `toon.ts`: original 600×1000 Canvas2D cartoon designs and facial expressions.
- `cast.ts`: lit camera-facing character cards and contact shadows.
- `world.ts`: lake, shore, drilling derrick, platform, barge, underground mine, flooding shaft, whirlpool, canal and per-frame animation.
- `LakePeigneur.tsx`: Remotion composition, ThreeCanvas scene, post chain and audio layers.
- `ink.ts`, `lensblur.ts`, `grade.ts`: adapted post-processing modules from the uploaded MIT-licensed project template.

## Determinism and continuity

- Scene geometry is created once in `World` and animated as a pure function of frame number.
- The procedural water texture uses fixed coordinates rather than `Math.random()`.
- The audio score and SFX are generated at exactly 48 kHz for 64 seconds.
- Character roles and costume colours are fixed in `toon.ts`.
- No captions, title card, intro logo, outro or CTA are generated.

## Validation status

- TypeScript / TSX syntax transpilation: passed.
- Python source syntax: passed.
- JSON configuration parsing: passed.
- Both WAV assets: verified stereo, 48 kHz, exactly 64 seconds.
- Full dependency-aware TypeScript typecheck: not run successfully because this workspace does not have the project's npm dependencies installed. Run `npm install` then `npm run typecheck` in the target repository.
- No Remotion preview, still render, test render or final video export was performed, as required.
