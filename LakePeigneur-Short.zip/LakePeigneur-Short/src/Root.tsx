import React from 'react';
import {Composition} from 'remotion';
import {LakePeigneurShort,LAKE_PEIGNEUR_FRAMES} from './videos/lakePeigneur/LakePeigneur';
export const RemotionRoot:React.FC=()=> <>
 <Composition id="LakePeigneurShort" component={LakePeigneurShort} durationInFrames={LAKE_PEIGNEUR_FRAMES} fps={30} width={1080} height={1920}/>
</>;
