import * as THREE from 'three';

export type ToonRole='driller'|'miner'|'fisher';
export type Face='neutral'|'worried'|'shocked'|'determined'|'relieved';
const cache=new Map<string,THREE.CanvasTexture>();
/** Original flat 2D cartoon character cards, designed for this story. */
export function toonTexture(role:ToonRole,face:Face='neutral'){
 const key=role+face;if(cache.has(key))return cache.get(key)!;
 const c=document.createElement('canvas');c.width=600;c.height=1000;const g=c.getContext('2d')!;
 const ink='#241726';
 const path=(pts:number[][])=>{g.beginPath();g.moveTo(pts[0][0],pts[0][1]);pts.slice(1).forEach(p=>g.lineTo(p[0],p[1]));};
 // legs and boots
 g.lineCap='round';g.lineJoin='round';g.strokeStyle=ink;g.lineWidth=24;
 g.beginPath();g.moveTo(270,710);g.lineTo(248,900);g.moveTo(335,710);g.lineTo(370,900);g.stroke();
 g.fillStyle='#40343a';g.beginPath();g.ellipse(230,920,64,28,-.1,0,Math.PI*2);g.ellipse(385,920,64,28,.1,0,Math.PI*2);g.fill();g.stroke();
 // torso and arms
 g.fillStyle=role==='miner'?'#d18a45':role==='fisher'?'#477d8b':'#6e777b';
 g.beginPath();g.roundRect(205,410,190,330,48);g.fill();g.strokeStyle=ink;g.lineWidth=18;g.stroke();
 g.lineWidth=20;g.beginPath();g.moveTo(210,455);g.lineTo(125,650);g.moveTo(390,455);g.lineTo(465,640);g.stroke();
 // head
 g.fillStyle='#f1d2b0';path([[190,130],[220,70],[300,48],[380,75],[415,145],[405,275],[350,345],[255,350],[190,285]]);g.closePath();g.fill();g.strokeStyle=ink;g.lineWidth=20;g.stroke();
 // hair / hardhat
 if(role==='miner'){g.fillStyle='#e8b74f';g.beginPath();g.roundRect(176,75,250,55,22);g.fill();g.stroke();g.beginPath();g.roundRect(245,42,110,50,20);g.fill();g.stroke();}
 else {g.fillStyle=role==='driller'?'#59453c':'#48372f';g.beginPath();g.moveTo(190,150);g.quadraticCurveTo(205,40,315,55);g.quadraticCurveTo(410,55,418,155);g.lineTo(380,126);g.lineTo(245,125);g.closePath();g.fill();g.stroke();}
 // expression
 const eyeY=205;g.fillStyle=ink;g.beginPath();g.ellipse(265,eyeY,13,face==='shocked'?22:14,0,0,Math.PI*2);g.ellipse(345,eyeY,13,face==='shocked'?22:14,0,0,Math.PI*2);g.fill();
 g.strokeStyle=ink;g.lineWidth=13;g.beginPath();
 if(face==='worried'||face==='shocked'){g.moveTo(245,170);g.lineTo(280,160);g.moveTo(330,160);g.lineTo(365,170);}else{g.moveTo(245,177);g.lineTo(280,180);g.moveTo(330,180);g.lineTo(365,177);}g.stroke();
 g.beginPath();if(face==='shocked'){g.ellipse(305,280,20,29,0,0,Math.PI*2);}else if(face==='relieved'){g.moveTo(275,275);g.quadraticCurveTo(305,300,340,275);}else if(face==='determined'){g.moveTo(270,285);g.lineTo(345,285);}else{g.moveTo(275,280);g.quadraticCurveTo(305,face==='worried'?260:300,340,280);}g.stroke();
 const tex=new THREE.CanvasTexture(c);tex.colorSpace=THREE.SRGBColorSpace;tex.needsUpdate=true;cache.set(key,tex);return tex;
}
