import * as THREE from 'three';
import {toonTexture,ToonRole,Face} from './toon';
import {NOINK} from './ink';
/** Camera-facing cartoon card with a soft, grounded shadow; card texture is original and reusable. */
export function makeActor(role:ToonRole,face:Face,scale=1){
 const group=new THREE.Group();
 const mat=new THREE.MeshLambertMaterial({map:toonTexture(role,face),transparent:true,alphaTest:.04,side:THREE.DoubleSide});
 const card=new THREE.Mesh(new THREE.PlaneGeometry(1.45*scale,2.42*scale),mat);card.position.y=1.22*scale;card.castShadow=false;card.userData.billboard=true;card.layers.set(NOINK);group.add(card);
 const shadow=new THREE.Mesh(new THREE.CircleGeometry(.48*scale,24),new THREE.MeshBasicMaterial({color:'#17212b',transparent:true,opacity:.24,depthWrite:false}));shadow.rotation.x=-Math.PI/2;shadow.position.y=.015;shadow.layers.set(NOINK);group.add(shadow);
 return group;
}
export function billboardActors(scene:THREE.Scene,camera:THREE.Camera){scene.traverse(o=>{if(o.userData.billboard)o.quaternion.copy(camera.quaternion)});}
