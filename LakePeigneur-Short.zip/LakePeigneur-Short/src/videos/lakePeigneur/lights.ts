export const PALETTE={
  ink:'#241726', water:'#248fa9', waterDeep:'#07506c', foam:'#d8f5ed', grass:'#557b43', mud:'#77634c', salt:'#d9d2c1',
  rig:'#b9a28a', rigDark:'#453d3c', sky:'#4d83bd', storm:'#526a83', gold:'#ffbd70', warning:'#e9a14a',
};
export const LIGHTS={
 day:{sky:'#79a9d8',ground:'#6b8061',sun:'#fff0d0',intensity:2.2,fog:'#a9c6d9'},
 storm:{sky:'#45576f',ground:'#33434b',sun:'#b3c4d6',intensity:1.1,fog:'#607687'},
 golden:{sky:'#d58b78',ground:'#79624e',sun:'#ffbb73',intensity:2.0,fog:'#dba68e'},
};
