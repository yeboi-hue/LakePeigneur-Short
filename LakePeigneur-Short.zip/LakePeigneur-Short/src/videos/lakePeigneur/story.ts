/** Lake Peigneur story timeline. 30 fps, 64 seconds, 9:16. All timing is deterministic. */
export const FPS = 30;
export const TOTAL = 64 * FPS;
export type V3 = [number, number, number];
export type Shot = { id:number; start:number; end:number; name:string; camera:V3; look:V3; fov:number; focus:number; light:'day'|'storm'|'golden'; };

export const SHOTS: Shot[] = [
  {id:1,start:0,end:150,name:'The impossible lake',camera:[0,9,24],look:[0,2,0],fov:39,focus:18,light:'day'},
  {id:2,start:150,end:300,name:'The drilling rig',camera:[-9,6,13],look:[0,5,0],fov:37,focus:12,light:'day'},
  {id:3,start:300,end:450,name:'The stuck drill',camera:[-3,4,8],look:[0,2,-1],fov:34,focus:8,light:'day'},
  {id:4,start:450,end:600,name:'The miners below',camera:[4,-3,11],look:[0,-7,0],fov:43,focus:12,light:'storm'},
  {id:5,start:600,end:750,name:'The first breach',camera:[1,4,9],look:[0,-1,0],fov:38,focus:9,light:'storm'},
  {id:6,start:750,end:900,name:'The whirlpool',camera:[0,15,21],look:[0,0,0],fov:42,focus:18,light:'storm'},
  {id:7,start:900,end:1050,name:'The platform goes',camera:[-7,5,13],look:[0,1,0],fov:39,focus:12,light:'storm'},
  {id:8,start:1050,end:1200,name:'The mine floods',camera:[0,-5,13],look:[0,-9,0],fov:42,focus:12,light:'storm'},
  {id:9,start:1200,end:1350,name:'The canal reverses',camera:[-36,10,18],look:[-48,0,-5],fov:39,focus:20,light:'storm'},
  {id:10,start:1350,end:1500,name:'The new lake',camera:[0,22,30],look:[0,0,0],fov:43,focus:24,light:'golden'},
  {id:11,start:1500,end:1650,name:'The aftermath',camera:[8,7,14],look:[0,0,0],fov:38,focus:14,light:'golden'},
  {id:12,start:1650,end:1800,name:'The survivors',camera:[-5,4,10],look:[0,2,0],fov:35,focus:11,light:'golden'},
  {id:13,start:1800,end:1920,name:'The final reveal',camera:[0,28,36],look:[0,-1,0],fov:44,focus:28,light:'golden'},
];
export const clamp=(v:number,a=0,b=1)=>Math.max(a,Math.min(b,v));
export const smooth=(v:number)=>{const t=clamp(v);return t*t*(3-2*t)};
export const ease=(v:number)=>1-Math.pow(1-clamp(v),3);
export function shotAt(frame:number){return SHOTS.find(s=>frame>=s.start&&frame<s.end)??SHOTS[SHOTS.length-1]}
export function shotProgress(frame:number,s=shotAt(frame)){return clamp((frame-s.start)/(s.end-s.start));}
export function phase(frame:number,a:number,b:number){return smooth((frame-a)/(b-a));}
export function whirlpoolStrength(frame:number){return phase(frame,690,1000)}
export function waterDrop(frame:number){return phase(frame,720,1080)}
export function mineFlood(frame:number){return phase(frame,600,1350)}
export function platformTilt(frame:number){return phase(frame,850,1010)}
