import * as THREE from 'three';
import {box,cylinder,beam,mat,waterTexture} from './build';
import {makeActor,billboardActors} from './cast';
import {PALETTE,LIGHTS} from './lights';
import {SHOTS,shotAt,shotProgress,phase,whirlpoolStrength,waterDrop,mineFlood,platformTilt,clamp} from './story';

const v=(a:number[])=>new THREE.Vector3(a[0],a[1],a[2]);
export class World{
 root=new THREE.Group(); private water:THREE.Mesh; private whirl=new THREE.Group(); private rig=new THREE.Group(); private mine=new THREE.Group(); private canal=new THREE.Group(); private platform=new THREE.Group(); private actors:THREE.Group[]=[]; private foam:THREE.Mesh[]=[]; private waterMat:THREE.MeshStandardMaterial; private sky:THREE.Mesh; private skyMat:THREE.MeshBasicMaterial; private canalTexture:THREE.Texture; private mineWater:THREE.Mesh; private waterShaft:THREE.Mesh; private sun:THREE.DirectionalLight; private hemi:THREE.HemisphereLight; private fog:THREE.Fog;
 constructor(){
  const R=this.root;
  this.fog=new THREE.Fog(LIGHTS.day.fog,35,260);
  this.skyMat=new THREE.MeshBasicMaterial({color:LIGHTS.day.sky,side:THREE.BackSide});this.sky=new THREE.Mesh(new THREE.SphereGeometry(500,32,18),this.skyMat);R.add(this.sky);
  this.hemi=new THREE.HemisphereLight('#d9efff','#4d5147',1.25);R.add(this.hemi);
  this.sun=new THREE.DirectionalLight('#fff0d2',2.2);this.sun.position.set(-35,55,25);this.sun.castShadow=true;this.sun.shadow.mapSize.set(2048,2048);R.add(this.sun,this.sun.target);
  const ground=box(180,1,180,mat('#647b50'),0,-1.8,0);R.add(ground);
  // Lake basin, shoreline and a distant tree line.
  const shore=new THREE.Mesh(new THREE.CircleGeometry(42,96),mat('#7e8761'));shore.rotation.x=-Math.PI/2;shore.position.y=-.12;R.add(shore);
  this.waterMat=new THREE.MeshStandardMaterial({map:waterTexture(),color:'#ffffff',roughness:.24,metalness:.04,transparent:false});
  this.water=new THREE.Mesh(new THREE.CircleGeometry(34,128),this.waterMat);this.water.rotation.x=-Math.PI/2;this.water.position.y=.05;this.water.receiveShadow=true;R.add(this.water);
  for(let i=0;i<34;i++){const a=i/34*Math.PI*2;const tree=new THREE.Group();const trunk=cylinder(.22,.32,2.2,mat('#69503b'),0,1,0,8);const crown=new THREE.Mesh(new THREE.IcosahedronGeometry(1.35+(i%3)*.2,1),mat(i%2?'#426a45':'#58794a'));crown.position.y=2.5;crown.castShadow=true;tree.add(trunk,crown);tree.position.set(Math.cos(a)*40,0,Math.sin(a)*40);R.add(tree);}
  // Rig platform and derrick. All pieces are simple but dimensional and outlined by the post pass.
  const deck=box(12,.75,8,mat('#766b5d'),0,2.2,0);this.platform.add(deck);
  for(const x of [-4.7,4.7])for(const z of [-2.8,2.8])this.platform.add(box(.55,2.2,.55,mat('#4e4b49'),x,1.05,z));
  this.platform.add(box(4,.35,2.8,mat('#a18d72'),0,2.8,0));
  const steel=mat('#8c8d89',.55),dark=mat('#454b4d',.55);
  const baseY=3.1,topY=18;
  for(const [x,z] of [[-1.5,-1.5],[1.5,-1.5],[-1.5,1.5],[1.5,1.5]]){
   this.rig.add(beam(new THREE.Vector3(x,baseY,z),new THREE.Vector3(x*.28,topY,z*.28),.12,steel));
   this.rig.add(beam(new THREE.Vector3(x,baseY,z),new THREE.Vector3(-x,baseY,-z),.07,dark));
  }
  for(let y=5;y<18;y+=2.3){this.rig.add(beam(new THREE.Vector3(-1.5,y,-1.5),new THREE.Vector3(1.5,y,1.5),.055,dark));this.rig.add(beam(new THREE.Vector3(1.5,y,-1.5),new THREE.Vector3(-1.5,y,1.5),.055,dark));}
  this.rig.add(box(4,.22,4,steel,0,18,0));this.rig.add(cylinder(.2,.2,4,dark,0,15,0));
  this.platform.add(this.rig);this.platform.position.set(-2,0,-1);R.add(this.platform);
  // Oil rig deck, crane and a supply barge.
  const barge=box(9,.8,4.5,mat('#5a5350'),-12,.1,6);R.add(barge);barge.rotation.y=-.16;
  const cabin=box(2,2,2,mat('#d4c6aa'),-13,1.5,6);R.add(cabin);
  // Underground mine cutaway: salt galleries, square pillars and a vertical breach shaft.
  const rock=mat('#756d66'),salt=mat('#d8d0bc'),shadow=mat('#3d3a3a');
  this.mine.add(box(45,1.5,30,rock,0,-13,0));
  for(let z=-10;z<=10;z+=5){this.mine.add(box(42,.65,1.1,salt,0,-8.5,z));}
  for(let x=-18;x<=18;x+=6)for(let z=-10;z<=10;z+=5){this.mine.add(box(1.8,8,1.8,salt,x,-8.5,z));}
  this.mine.add(box(2,12,2,shadow,0,-4.8,0));
  const mineWaterMat=new THREE.MeshStandardMaterial({color:'#269bb7',transparent:true,opacity:.72,roughness:.22,metalness:.02,side:THREE.DoubleSide});
  this.mineWater=new THREE.Mesh(new THREE.BoxGeometry(43,.28,27),mineWaterMat);this.mineWater.position.set(0,-12,0);this.mine.add(this.mineWater);
  this.waterShaft=cylinder(.48,.72,8,new THREE.MeshStandardMaterial({color:'#6bd1d5',transparent:true,opacity:.62,roughness:.2}),0,-1.5,0,16);this.mine.add(this.waterShaft);
  // Mine entrance cutaway wall edges.
  this.mine.add(box(46,2,1.2,rock,0,-2.5,-15));this.mine.position.y=-1;R.add(this.mine);
  // Whirlpool rings: concentric torus bands and white foam flecks.
  const ringMat=new THREE.MeshStandardMaterial({color:PALETTE.foam,roughness:.35,transparent:true,opacity:.8});
  for(let i=0;i<7;i++){const ring=new THREE.Mesh(new THREE.TorusGeometry(4+i*2.1,.11+(i%2)*.06,8,100),ringMat);ring.rotation.x=Math.PI/2;ring.position.y=.24+i*.012;this.whirl.add(ring);}
  for(let i=0;i<18;i++){const fleck=new THREE.Mesh(new THREE.SphereGeometry(.12+(i%3)*.06,8,6),new THREE.MeshBasicMaterial({color:'#e4f7f0'}));this.foam.push(fleck);this.whirl.add(fleck);}
  this.whirl.position.set(0,.15,0);R.add(this.whirl);
  // Canal ribbon and an inland-to-lake cascade. Water flow reverses during the event.
  this.canalTexture=waterTexture();this.canalTexture.repeat.set(1,8);const canalWater=new THREE.Mesh(new THREE.BoxGeometry(7,.22,58),new THREE.MeshStandardMaterial({map:this.canalTexture,color:'#ffffff',roughness:.25}));canalWater.position.set(-48,.05,-3);this.canal.add(canalWater);
  for(let x of [-52,-44]){this.canal.add(box(.5,1,58,mat('#8b876e'),x,-.2,-3));}
  const fall=new THREE.Mesh(new THREE.PlaneGeometry(7,18),new THREE.MeshBasicMaterial({color:'#b9e8e8',transparent:true,opacity:.8,side:THREE.DoubleSide}));fall.position.set(-48,-7,-3);this.canal.add(fall);R.add(this.canal);
  // Original cast: drill crew, miners and a fisherman, each as flat character cards.
  const cast=[makeActor('driller','worried',1.1),makeActor('driller','shocked',1),makeActor('miner','worried',.95),makeActor('miner','determined',.95),makeActor('fisher','shocked',1.05),makeActor('miner','relieved',.95)];
  cast.forEach((a,i)=>{a.position.set([-5,-3,3,6,-16,1][i],i===2||i===3?-8.8:.1,[1,-2,-12,-9,9,-7][i]);this.actors.push(a);R.add(a);});
  // Sparse clouds, intentionally simple and distant.
  for(let i=0;i<7;i++){const cl=new THREE.Mesh(new THREE.SphereGeometry(3+i%3,12,8),new THREE.MeshBasicMaterial({color:'#f4f1ec',transparent:true,opacity:.65}));cl.scale.set(1.8,.45,1);cl.position.set(-60+i*20,27,-70+(i%3)*24);R.add(cl);}
 }
 update(frame:number,camera:THREE.PerspectiveCamera,scene:THREE.Scene){
  scene.fog=this.fog;
  const s=shotAt(frame),p=shotProgress(frame,s),prev=SHOTS[Math.max(0,s.id-2)];
  const start=prev? v(prev.camera):v(s.camera),end=v(s.camera);camera.position.copy(start.lerp(end,easeIn(p)));camera.position.y+=Math.sin(frame*.012)*.08;
  const target=v(s.look);target.y+=Math.sin(frame*.009)*.12;camera.lookAt(target);camera.fov=s.fov;camera.updateProjectionMatrix();
  const light=LIGHTS[s.light];this.skyMat.color.set(light.sky);this.hemi.color.set(light.sky);this.hemi.groundColor.set(light.ground);this.sun.color.set(light.sun);this.sun.intensity=light.intensity;this.fog.color.set(light.fog);
  const drop=waterDrop(frame),vortex=whirlpoolStrength(frame),flood=mineFlood(frame),tilt=platformTilt(frame);
  this.water.scale.setScalar(1-.2*drop);this.water.position.y=.05-.5*drop;
  this.waterMat.color.setRGB(1-.18*drop,1-.1*drop,1-.02*drop);if(this.waterMat.map)this.waterMat.map.offset.x=frame*.0012;
  this.whirl.visible=frame>650&&frame<1390;this.whirl.scale.setScalar(.35+vortex*1.1);this.whirl.rotation.y=frame*.035;this.whirl.position.y=.2+vortex*.25;
  this.foam.forEach((f,i)=>{const a=frame*.035+i*2.4,r=3+(i%6)*2.3;f.position.set(Math.cos(a)*r,.3+Math.sin(a*2)*.08,Math.sin(a)*r);});
  this.platform.rotation.z=-tilt*.9;this.platform.rotation.x=tilt*.22;this.platform.position.y=-tilt*1.2;
  this.mine.visible=frame>390&&frame<1450;this.mine.position.y=-1+flood*2.4;this.mineWater.position.y=-12+flood*5.6;this.waterShaft.visible=frame>590&&frame<1250;
  this.canal.visible=frame>1190;this.canal.rotation.y=frame>1190?Math.sin(frame*.012)*.015:0;this.canalTexture.offset.x=frame>1190?-(frame-1190)*.006:frame*.0015;
  this.actors.forEach((a,i)=>{a.visible=([0,1,4].includes(i)?frame<1100:i===2||i===3?frame>360&&frame<1380:frame>1450);a.position.y=(i===2||i===3?-8.8+phase(frame,650,800)*8.9:(i===0||i===1?3.0-tilt*1.2:.12))+Math.sin(frame*.06+i)*.035;if(i===0){a.position.x=-5+tilt*2;}if(i===1){a.position.x=-2+tilt*2;}});
  billboardActors(this.root as unknown as THREE.Scene,camera);
 }
}
function easeIn(v:number){const t=clamp(v);return t*t*(3-2*t);}
