import React,{useMemo} from 'react';
import * as THREE from 'three';
import {AbsoluteFill,Audio,staticFile,useCurrentFrame,getInputProps} from 'remotion';
import {ThreeCanvas} from '@remotion/three';
import {useThree,useFrame} from '@react-three/fiber';
import {EffectComposer} from '@react-three/postprocessing';
import {BlendFunction,BloomEffect,ToneMappingEffect,ToneMappingMode} from 'postprocessing';
import {World} from './world';
import {InkPass} from './ink';
import {LensBlur} from './lensblur';
import {GradeEffect,GRADES,gradeFor} from './grade';
import {shotAt,shotProgress} from './story';

export const LAKE_PEIGNEUR_FRAMES=64*30;
const Inner:React.FC=()=>{
 const frame=useCurrentFrame();
 const {camera,scene}=useThree();
 const world=useMemo(()=>new World(),[]);
 const fx=useMemo(()=>({
  ink:new InkPass(scene,camera as THREE.PerspectiveCamera),
  lens:new LensBlur({maxCoC:24,nearScale:1.15}),
  bloom:new BloomEffect({blendFunction:BlendFunction.ADD,intensity:.48,luminanceThreshold:1.0,luminanceSmoothing:.2,mipmapBlur:true,levels:6,radius:.6}),
  tone:new ToneMappingEffect({mode:ToneMappingMode.NEUTRAL}),
  grade:new GradeEffect(GRADES.day),
 }),[camera,scene]);
 React.useEffect(()=>()=>fx.ink.dispose(),[fx]);
 useFrame(()=>{
  world.update(frame,camera as THREE.PerspectiveCamera,scene);
  const shot=shotAt(frame);const p=shotProgress(frame,shot);
  const focus=shot.focus;
  fx.lens.focus=Math.max(.3,focus);
  fx.lens.cInf=shot.name.includes('final')?0:shot.name.includes('impossible')?0:12+Math.sin(p*Math.PI)*2;
  gradeFor(fx.grade,shot.light==='golden'?'golden':'day');
 });
 return <>
  <primitive object={world.root} dispose={null}/>
  <EffectComposer multisampling={4}>
   <primitive object={fx.ink} dispose={null}/>
   <primitive object={fx.lens.pre} dispose={null}/>
   <primitive object={fx.lens.main} dispose={null}/>
   <primitive object={fx.bloom} dispose={null}/>
   <primitive object={fx.tone} dispose={null}/>
   <primitive object={fx.grade} dispose={null}/>
  </EffectComposer>
 </>;
};

export const LakePeigneurShort:React.FC=()=>{
 const frame=useCurrentFrame();
 const flash=frame>=690&&frame<694?[1,.72,.4,.16][frame-690]:0;
 return <AbsoluteFill style={{background:'#7898ae'}}>
  <ThreeCanvas width={1080} height={1920} shadows gl={{antialias:false,stencil:false,powerPreference:'high-performance',toneMappingExposure:1}} camera={{fov:40,near:.2,far:1200,position:[0,8,24]}}>
   <Inner/>
  </ThreeCanvas>
  <Audio src={staticFile('audio/lake-peigneur-score.wav')} volume={.25}/>
  <Audio src={staticFile('audio/lake-peigneur-sfx.wav')} volume={.38}/>
  {(getInputProps() as {voiceFile?:string}).voiceFile ? <Audio src={staticFile((getInputProps() as {voiceFile:string}).voiceFile)} volume={1}/> : null}
  {flash>0&&<AbsoluteFill style={{background:'#fff',opacity:flash}}/>}
 </AbsoluteFill>;
};
